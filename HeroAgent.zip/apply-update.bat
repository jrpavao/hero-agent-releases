@echo off
:: HeroControl Auto-Update Script
:: Called by WinMetricsSvc in a fire-and-forget manner to replace itself.
set LOGFILE=C:\ProgramData\HeroControl\agent_log.txt
echo %date% %time% [Update] apply-update.bat initiated... >> %LOGFILE%

:: Wait 3 seconds to let the Service exit completely.
timeout /t 3 /nobreak > nul

echo %date% %time% [Update] Stopping WinMetricsSvc... >> %LOGFILE%
net stop WinMetricsSvc >> %LOGFILE% 2>&1

:: Double check with sc query
sc query WinMetricsSvc | find "STOPPED"
if errorlevel 1 (
    echo %date% %time% [Update] Force killing WinMetricsSvc... >> %LOGFILE%
    taskkill /F /IM WinMetricsSvc.exe >> %LOGFILE% 2>&1
)

:: Stop Agent to update it too
taskkill /F /IM WinMetricsAgent.exe >> %LOGFILE% 2>&1

:: Replace files
set INSTALLDIR=C:\ProgramData\HeroControl
set UPDATEDIR=C:\ProgramData\HeroControl\UpdateTemp

echo %date% %time% [Update] Copying files from %UPDATEDIR% to %INSTALLDIR%... >> %LOGFILE%
xcopy /Y /S /E /H /R /C "%UPDATEDIR%\*" "%INSTALLDIR%\" >> %LOGFILE% 2>&1

:: Clean up update directory
rmdir /S /Q "%UPDATEDIR%" >> %LOGFILE% 2>&1

:: Restart Service
echo %date% %time% [Update] Starting WinMetricsSvc... >> %LOGFILE%
net start WinMetricsSvc >> %LOGFILE% 2>&1

:: Agent start will happen periodically by the Service's Watchdog if needed.
echo %date% %time% [Update] Update complete. >> %LOGFILE%
exit /b 0
